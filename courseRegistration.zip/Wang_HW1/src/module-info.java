/**
 * 
 */
/**
 * 
 */
module Wang_HW1 {
}